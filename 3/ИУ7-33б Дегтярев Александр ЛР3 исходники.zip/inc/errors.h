#ifndef __ERRORS_H__
#define __ERRORS_H__

#define OK 0
#define ERR 1
#define EMEM 2
#define EMATRIXMUL 3
#define EMATRIXZERO 4

#endif // __ERRORS_H__
